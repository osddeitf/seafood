$('#pay_international1').on("click", function () {
    $('#pay_international_ctn1').toggle(200);
});

$('#pay_international2').on("click", function () {
    $('#pay_international_ctn2').toggle(200);
});




$('.js_em_active span').each(function (index) {
    $(this).on("click", function () {
        $('.js_em_active span').removeClass('em_active');
        $(this).addClass('em_active');
    });
});



$('#payment_type_form_continue').on("click", function (e) {
    e.preventDefault();
    $('#payment_type_form').hide(10);
    $('#international_form').show(10);
    $('html,body').animate({scrollTop: 0}, 500);
    return false;
});

$('#international_form_continue').on("click", function (e) {
    e.preventDefault();
    $('#international_form').hide(10);
    $('#local_payment_form').show(10);
    $('html,body').animate({scrollTop: 0}, 500);
    return false;
});

$('#local_payment_form_continue').on("click", function (e) {
    e.preventDefault();
    $('#local_payment_form').hide(10);
    $('#local_otp_form').show(10);
    $('html,body').animate({scrollTop: 0}, 500);
    return false;
});

$('#local_otp_form_continue').on("click", function (e) {
    e.preventDefault();
    $('#local_otp_form').hide(10);
    $('#payment_success_form').show(10);
    $('html,body').animate({scrollTop: 0}, 500);
    return false;
});

$('.em_small_box .vd_table_ticket').each(function (index) {
    $(this).on("click", function () {
        $('.em_small_box .vd_table_ticket').removeClass('vd_active');
        $(this).addClass('vd_active');
    });
});