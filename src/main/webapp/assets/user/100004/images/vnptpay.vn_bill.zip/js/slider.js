$(function() {
  $('#myCarousel').carousel();

  $("#myCarousel").swipe({
    swipeRight: function() {
      $(this).carousel('prev')
    },
    swipeLeft: function() {
      $(this).carousel('next')
    }
  });
})


// Form JS
// kanban select
$('.js_em_kanban_view a').each(function(index) {
    $(this).on("click", function(){
        $('#dropdown-telecom').html($(this).data('name') + '<span class="caret"></span>');
        $('.js_em_kanban_view a').removeClass('active');
        $(this).addClass('active');
    });
});

// price selector
$('#dropdown-price').each(function(index) {
    var self = this;
    $(self).parent().find('li a').each(function(index) {
        $(this).on("click", function(){
            $(self).html($(this).text() + '<span class="caret"></span>');
            $(self).parent().find('li').removeClass('active');
            $(this).parent().addClass('active');
        });
    });
});

$('#dropdown-price-2').each(function(index) {
    var self = this;
    $(self).parent().find('li a').each(function(index) {
        $(this).on("click", function(){
            $(self).html($(this).text() + '<span class="caret"></span>');
            $(self).parent().find('li').removeClass('active');
            $(this).parent().addClass('active');
        });
    });
});

// telecom selector
$('#dropdown-price-3').each(function(index) {
    var self = this;
    $(self).parent().find('li a').each(function(index) {
        $(this).on("click", function(){
            $(self).html($(this).html());
            $(self).parent().find('li').removeClass('active');
            $(this).parent().addClass('active');
        });
    });
});
$('#dropdown-price-3').each(function(index) {
    var self = this;
    $(self).parent().find('li a').each(function(index) {
        $(this).on("click", function(){
            $(self).html($(this).html());
            $(self).parent().find('li').removeClass('active');
            $(this).parent().addClass('active');
        });
    });
});

$('#dropdown-price-4').each(function(index) {
    var self = this;
    $(self).parent().find('li a').each(function(index) {
        $(this).on("click", function(){
            $(self).html($(this).html());
            $(self).parent().find('li').removeClass('active');
            $(this).parent().addClass('active');
        });
    });
});