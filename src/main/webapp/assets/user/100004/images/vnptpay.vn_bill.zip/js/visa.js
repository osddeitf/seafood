$("#button-cvv").click(function() {
	if ($("#button-div").hasClass("hide")) {
		$("#button-div").removeClass("hide");
	}else {
		$("#button-div").addClass("hide");
	}
});

$("#select-type").change(function() {
	if ($("#select-type").val() == 'cif') {
		$("#account").attr("style","display: none;");
		$("#card").attr("style","display: none;");
		$("#cif").removeAttr("style")
	}else if ($("#select-type").val() == 'account') {
		$("#cif").attr("style","display: none;");
		$("#card").attr("style","display: none;");
		$("#account").removeAttr("style");
	}else if ($("#select-type").val() == 'card') {
		$("#cif").attr("style","display: none;");
		$("#account").attr("style","display: none;");
		$("#card").removeAttr("style");
	}
});